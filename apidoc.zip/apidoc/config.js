// eslint-disable-next-line no-unused-vars
var config = {
  // 请求host
  HOST: "",
  // 菜单配置
  MENU: {
    // 是否显示控制器类名
    SHOW_CONTROLLER_CLASS: true,
    // 是否显示接口url
    SHOW_API_URL: true,
    // 是否显示接口请求类型
    SHOW_API_METHOD: true
  }
};
